interface ITournament {
  int countUnderdogWins (); 
  boolean winnersAlwaysPlayed (); 
  boolean anySkippedMatches ();
}
