interface IContestant {
  boolean isUnderdog();
  boolean isNotYetKnown();
}
