class NotYetKnown implements IContestant {
 NotYetKnown () {}
 public boolean isNotYetKnown () {
   return true;
 }
 public boolean isUnderdog () {
   return false;
 }
} 

//this is for the unknown winners of matches for tournaments not finished yet.